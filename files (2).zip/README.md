# Patsiuk: the dog that checks drone-flagged metal

Drones find every piece of metal. Patsiuk walks to each flagged spot, scans it at
ground level with two phones (a gradiometer), fits a magnetic dipole, and sorts it:

| Label | Meaning |
|---|---|
| `MINE_SIZED` | enough steel to be a mine or UXO. Send a human (EOD). |
| `FRAGMENT` | small steel object: scrap, low priority. |
| `NO_TARGET` | nothing ferrous above the noise. |
| `RESCAN` | something is there but the fit is poor. Never treated as safe. |

The dog keeps one heading all run and never steps on a flagged spot (`plan_move`).

## Files
- `field_scan.py`: main program (scan, fit, classify, map, status server on :8765)
- `dipole.py`: physics and fit. `python dipole.py` runs a self-test showing a big deep object and a small shallow one with the same peak signal, told apart by the fit.
- `phones.py`: phyphox reader and live hand-test tool
- `robot.py`: dimOS mover (Go2) and manual mover (handheld rig)
- `sim.py`: fake world, phones and dog
- `flagged_spots.json`: the "drone survey" input (remove `sim_truth` for real runs)
- `unoq/`: optional Arduino UNO Q status display (App Lab app: `sketch/` + `python/`)

`pip install numpy scipy matplotlib`

## Test order (do not skip steps)
1. `python field_scan.py --sim`: whole pipeline, no hardware.
2. **Hand test (10 min):** phyphox on both phones, open Magnetometer, menu, Allow remote access. Everything on ONE hotspot.
   `python phones.py http://LOW:8080 http://HIGH:8080`. Sweep over a steel pot and over keys.
   You need changes of several uT at 5 to 10 cm, and noise well under 0.5 uT.
3. **Handheld rig:** tape a grid on the floor, then
   `python field_scan.py --manual --low http://LOW:8080 --high http://HIGH:8080`
4. **Dog:** `dimos mcp list-tools` to confirm the move skill and its argument names, then test a +5 cm forward and a +5 cm left move for direction.
   Find the smallest move the dog does accurately and set `--step` to at least that.
   `python field_scan.py --low http://LOW:8080 --high http://HIGH:8080 [--skill ... --fwd-arg ... --left-arg ...]`

## Mounting (measure and pass these)
- Phones flat, screen up, top of phone pointing forward along the boom.
- `--h-low` / `--h-high`: height of each phone above the ground with the dog standing (default 0.05 / 0.35 m).
- `--boom`: horizontal distance from the dog's body centre to the phones (default 0.65 m). Longer means less dog interference.
- Non-metal boom only (wood, PVC, cardboard). Keep keys and phones in pockets away from the rig.

## Calibrate the threshold (5 min)
Scan one mine stand-in (steel pot or tin) and one fragment (keys) with `--calibrate`.
Set `--threshold` to about `sqrt(moment_big * moment_small)`.

## Limits (say them before judges ask)
- Ferrous (steel) targets only: UXO and steel-cased mines, not plastic mines.
- Signals under about 1 uT peak-to-peak are reported `NO_TARGET`. For a pot-sized object that is roughly 15 to 20 cm deep.
- If a phone's reading suddenly jumps several uT, the OS recalibrated its magnetometer. Rescan that spot.
- Positions are the dog's commanded moves, so accuracy depends on how precisely it steps.
