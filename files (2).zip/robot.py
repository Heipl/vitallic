"""
robot.py - move the sensor. The dog keeps ONE heading for the whole run
(facing +x) and only steps forward/back and sideways. That keeps the dog's own
magnetic field constant at the phones, so the fit's offsets cancel it.

Before the first run:  dimos mcp list-tools
and check the move skill name and argument names; pass them with
--skill / --fwd-arg / --left-arg if they differ from the defaults.
Test signs with a tiny move first: +forward must go forward, +left must go left.
"""
import subprocess
import time


class DimosMover:
    """Moves a Unitree Go2 through dimOS MCP skills via the `dimos` CLI."""

    def __init__(self, skill="relative_move", fwd_arg="forward", left_arg="left",
                 observe_skill="observe", settle=0.8, min_move=0.01):
        self.skill, self.fwd_arg, self.left_arg = skill, fwd_arg, left_arg
        self.observe_skill, self.settle, self.min_move = observe_skill, settle, min_move

    def _call(self, *parts, timeout=60):
        cmd = ["dimos", "mcp", "call", *parts]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if r.returncode != 0:
            raise RuntimeError(f"`{' '.join(cmd)}` failed:\n{r.stderr.strip() or r.stdout.strip()}")
        return r.stdout.strip()

    def move(self, dx, dy, target=None):
        """Relative move of the dog body in metres (x forward, y left). One axis per
        call so it works even if the skill only accepts one argument at a time."""
        if abs(dx) >= self.min_move:
            self._call(self.skill, "--arg", f"{self.fwd_arg}={dx:.3f}")
        if abs(dy) >= self.min_move:
            self._call(self.skill, "--arg", f"{self.left_arg}={dy:.3f}")
        time.sleep(self.settle)  # let the body stop swaying before we measure

    def observe(self):
        try:
            return self._call(self.observe_skill, timeout=90)
        except Exception as e:
            return f"(observe unavailable: {e})"


class ManualMover:
    """Handheld mode: carry the two-phone rig over a tape grid on the floor.
    Lets you test the whole pipeline without dog time."""

    def move(self, dx, dy, target=None):
        where = f" to x={target[0]*100:.0f} cm, y={target[1]*100:.0f} cm" if target is not None else \
                f" by forward {dx*100:+.0f} cm, left {dy*100:+.0f} cm"
        input(f"  put the phones{where} (keep the same heading), then Enter ")

    def observe(self):
        return ""
